/* COMP 371 - QUIZ 1
   Daniel Lam - 40248073
*/

#include <iostream>
#include<vector>

#define GLEW_STATIC 1   // This allows linking with Static Library on Windows, without DLL
#include <GL/glew.h>    // Include GLEW - OpenGL Extension Wrangler

#include <GLFW/glfw3.h> // GLFW provides a cross-platform interface for creating a graphical context,
                        // initializing OpenGL and binding inputs

#include <glm/glm.hpp>  // GLM is an optimized math library with syntax to similar to OpenGL Shading Language
#include <glm/gtc/matrix_transform.hpp> // include this to create transformation matrices
#include <glm/gtc/type_ptr.hpp>
#include <cmath>
#include <random>
using namespace std;
using namespace glm;

// GLOBAL VARIABLES
#define INFO_LOG_SIZE 512
#define WINDOW_WIDTH 1024
#define WINDOW_HEIGHT 768
#define ASPECT_RATIO ((float)WINDOW_WIDTH/(float)WINDOW_HEIGHT)
#define GRID_SLICES_X 78
#define GRID_SLICES_Z 36

#define STBI_FAILURE_USERMSG
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

const float RIGHT_ANGLE = pi<float>()/2;
const float CORNER_ANGLE = pi<float>()/4; // desired corner angle assuming starting from horizontal
const float RACKET_ANGLE = RIGHT_ANGLE - CORNER_ANGLE;
const mat4 IDENTITY_MATRIX(1.0f);
const mat4 TRANSLATE_ABOVE_RACKET = translate(IDENTITY_MATRIX, vec3(0.0f, 10.0f, 0.0f));

// COLORS
const vec3 colorLightRed = vec3(220/255.0f, 20/255.0f, 60/255.0f);
const vec3 colorRed = vec3(1.0f, 0.0f, 0.0f);
const vec3 colorDarkRed = vec3(139/255.0f, 0.0f, 0.0f);
const vec3 colorLightYellow = vec3(1.0f, 1.0f, 153/255.0f);
const vec3 colorYellow = vec3(1.0f, 1.0f, 0.0f);
const vec3 colorDarkYellow = vec3(204/255.0f, 204/255.0f, 0.0f);
const vec3 colorLightBlue = vec3(30.0/255.0f, 144.0/255.0f, 255.0/255.0f);
const vec3 colorBlue = vec3(0.0f, 0.0f, 1.0f);
const vec3 colorDarkBlue = vec3(0.0f, 0.0f, 139.0/255.0f);
const vec3 colorLightGreen = vec3(124/255.0f, 252/255.0f, 0.0f);
const vec3 colorGreen = vec3(0.0f, 1.0f, 0.0f);
const vec3 colorDarkGreen = vec3(0.0f, 100.0/255.0f, 0.0f);
const vec3 colorBeige = vec3(238.0/255.0f, 217.0/255.0f, 196.0/255.0f);
const vec3 colorWhite = vec3(1.0f, 1.0f, 1.0f);
const vec3 colorGray = vec3(80.0/255.0f, 80.0/255.0f, 80.0/255.0f);
const vec3 colorSkybox = vec3(173/255.0f, 216/255.0f, 230/255.0f);

// Initialize Group Racket Matrices

// STRUCT
typedef struct racketMatrices {
    mat4 racketTranslation;
    mat4 racketRotation;
    mat4 groupMatrix;

    vec3 returnRacketCenter() {
        return racketTranslation * vec4(0.0f, 7.0f, 0.0f, 1.0f);
    }

    void updateGroupMatrix() {
        groupMatrix = racketTranslation * racketRotation;
    }

    // Constructor with default values
    racketMatrices() : racketTranslation(mat4(1.0f)), racketRotation(mat4(1.0f)), groupMatrix(mat4(1.0f)) {}
} racketMatrices;

racketMatrices groupFirstRacketDA;
racketMatrices groupSecondRacketNI;
racketMatrices* currentlySelectedGroupRacket = NULL;


// SHADER SOURCES - TEXTURE
const char* textureVertexShaderSource = R"(
    #version 330 core
    layout (location = 0) in vec3 aPos;
    layout (location = 1) in vec3 aColor;
    layout (location = 2) in vec3 aNormal;
    layout (location = 3) in vec2 aUV;

    uniform vec3 color;
    uniform vec3 lightPos;
    uniform mat4 model = mat4(1.0);
    uniform mat4 view = mat4(1.0);
    uniform mat4 proj = mat4(1.0);

    out vec3 vertexColor;
    out vec3 pos;
    out vec3 normal;
    out vec3 eyeDir;
    out vec3 lightDir;
    out vec2 vertexUV;

    

    void main() {
        vertexColor = color;
        mat4 MVP = proj * view * model;
        gl_Position = MVP * vec4(aPos, 1.0);

        pos = (model * vec4(aPos, 1)).xyz;
        vec3 vertexPosition = ( view * model * vec4(aPos, 1)).xyz;
        eyeDir = vec3(0,0,0) - vertexPosition;

        vec3 lightPosCamera = ( view * vec4(lightPos, 1)).xyz;
        lightDir = lightPosCamera + eyeDir;
        normal = (transpose(inverse(view * model)) * vec4(aNormal, 1)).xyz;

        vertexUV = aUV;
    }

)";

const char* textureFragmentShaderSource = R"(
    #version 330 core

    uniform vec3 lightPos;
    uniform sampler2D textureSampler;

    in vec3 vertexColor;
    in vec3 pos;
    in vec3 normal;
    in vec3 eyeDir;
    in vec3 lightDir;
    in vec2 vertexUV;

    out vec3 FragColor;

    void main() {
        vec4 textureColor = texture( textureSampler, vertexUV ); 


        vec3 lightColor = vec3(1.0f, 1.0f, 1.0f);
        float lightPower = 100.0f;

        vec3 diffuseFactor = vec3(1.0f, 1.0f, 1.0f); 
        vec3 ambientFactor = vec3(0.3f, 0.3f, 0.3f);
        vec3 specularFactor = vec3(1.0f, 1.0f, 1.0f);

        float dist = length(lightPos - pos);
        vec3 n = normalize(normal);
        vec3 l = normalize(lightDir);

        float cosTheta = clamp(dot(n,l), 0, 1);

        vec3 E = normalize(eyeDir);
        vec3 R = reflect(-l, n);

        float cosAlpha = clamp(dot(E, R), 0, 1);

        vec3 ambientColor = vertexColor * ambientFactor;
        vec3 diffuseColor = vertexColor * diffuseFactor * lightColor * lightPower * cosTheta / (1 + dist * 0.5 + dist * dist * 0.05);
        vec3 specularColor = specularFactor * lightColor * lightPower * pow(cosAlpha,5) / (1 + dist * 0.5 + dist * dist * 0.05);

        FragColor = vec3(textureColor) * (ambientColor + diffuseColor) + specularColor;
    }
)";

// This function loads and compile a shader code provided in a string format.
GLuint loadAndCompileShader(const char * shaderSource, GLenum shaderType) {
    int success;
    char infoLog[INFO_LOG_SIZE];

    GLuint shaderId = glCreateShader(shaderType);
    glShaderSource(shaderId, 1, &shaderSource, NULL);
    glCompileShader(shaderId);

    glGetShaderiv(shaderId, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(shaderId, 512, NULL, infoLog);
        fprintf(stderr, "ERROR::SHADER::COMPILATION_FAILED\n%s\n%s", infoLog, shaderSource);
        exit(EXIT_FAILURE);
    }
    return shaderId;
}

void computeGrid(GLuint & VAOGrid, GLuint & VBOGrid, GLuint & EBOGrid, GLuint & EBOGridLength) {
    
    vector<vec3> verticesGrid;
    vector<GLuint> indicesGrid;

    GLfloat gridMiddleX = GRID_SLICES_X/2.0f;
    GLfloat gridMiddleZ = GRID_SLICES_Z/2.0f;

    // Compute vertices on X axis
    for (int i = 0; i <= GRID_SLICES_Z; i++) {
        // set a pair of vertices to form a line, placing one on positive x and other on negative x.
        // Building lines from the negative z axis to the positive axis.
        verticesGrid.push_back(vec3(-gridMiddleX, 0.0f, -gridMiddleZ + i));
        verticesGrid.push_back(vec3(gridMiddleX, 0.0f, -gridMiddleZ + i));
    }

    for (int i = 0; i <= GRID_SLICES_X; i++) {
        // set a pair of vertices to form a line, placing one on positive x and other on negative x.
        // Building lines from the negative z axis to the positive axis.
        verticesGrid.push_back(vec3(-gridMiddleX + i, 0.0f, -gridMiddleZ));
        verticesGrid.push_back(vec3(-gridMiddleX + i, 0.0f, gridMiddleZ));
    }

    // Compute correspond
    for (int i = 0; i < verticesGrid.size(); i++) {
        indicesGrid.push_back(i);
    }

    glGenVertexArrays(1, &VAOGrid);
    glBindVertexArray(VAOGrid);

    
    glGenBuffers(1, &VBOGrid);
    glBindBuffer(GL_ARRAY_BUFFER, VBOGrid);
    glBufferData(GL_ARRAY_BUFFER, verticesGrid.size()*sizeof(vec3), &verticesGrid[0][0], GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(vec3), (void*)0);
    glEnableVertexAttribArray(0);
    
    glGenBuffers(1, &EBOGrid);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBOGrid);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indicesGrid.size()*sizeof(GLuint), &indicesGrid[0], GL_STATIC_DRAW);

    EBOGridLength = indicesGrid.size();
}


// drawCubeModel() sets up vertices & indices of base cube and allows rendering in Triangles with respective EBOGrid
void drawCubeModel(GLuint &VAOCubeModel, GLuint &VBOCubeModel, GLuint &EBOCubeModel, GLuint &EBOCubeModelLength) {
    
    // VERTICES OF CUBE
    std::vector<vec3> cubeVertices = {
        // position vertices
        // front face
        vec3(-0.5f, -0.5f, 0.5f), // 0: front bottom left - normal: -x 
        vec3(-0.5f, -0.5f, 0.5f), // 1: normal: -y
        vec3(-0.5f, -0.5f, 0.5f), // 2: normal: z

        vec3(-0.5f, 0.5f, 0.5f), // 3: front top left - normal: -x 
        vec3(-0.5f, 0.5f, 0.5f), // 4: normal: y
        vec3(-0.5f, 0.5f, 0.5f), // 5: normal: z

        vec3(0.5f, 0.5f, 0.5f), // 6: front top right - normal: x
        vec3(0.5f, 0.5f, 0.5f), // 7: normal: y
        vec3(0.5f, 0.5f, 0.5f), // 8: normal: z

        vec3(0.5f, -0.5f, 0.5f), // 9: front bottom right - normal: x
        vec3(0.5f, -0.5f, 0.5f), // 10: normal: -y
        vec3(0.5f, -0.5f, 0.5f), // 11: normal: z
        
        // back face
        vec3(-0.5f, -0.5f, -0.5f), // 12: back bottom left - normal: -x
        vec3(-0.5f, -0.5f, -0.5f), // 13: normal: -y
        vec3(-0.5f, -0.5f, -0.5f), // 14: normal: -z

        vec3(-0.5f, 0.5f, -0.5f), // 15: back top left - normal: -x
        vec3(-0.5f, 0.5f, -0.5f), // 16: normal: y
        vec3(-0.5f, 0.5f, -0.5f), // 17: normal: -z

        vec3(0.5f, 0.5f, -0.5f), // 18: back top right - normal: x
        vec3(0.5f, 0.5f, -0.5f), // 19: normal: y
        vec3(0.5f, 0.5f, -0.5f), // 20: normal: -z

        vec3(0.5f, -0.5f, -0.5f), // 21: back bottom right - normal: x
        vec3(0.5f, -0.5f, -0.5f), // 22: normal: -y
        vec3(0.5f, -0.5f, -0.5f), // 23: normal: -z

    };

    std::vector<vec3> cubeNormals = {
        // normals (6 normals per face as every position vertex is being used 6 times)
        vec3(-1.0f, 0.0f, 0.0f), // front bottom left - normal: -x
        vec3(0.0f, -1.0f, 0.0f), // normal: -y
        vec3(0.0f, 0.0f, 1.0f), // normal: z

        vec3(-1.0f, 0.0f, 0.0f), // front top left - normal: -x 
        vec3(0.0f, 1.0f, 0.0f), // normal: y
        vec3(0.0f, 0.0f, 1.0f), // normal: z

        vec3(1.0f, 0.0f, 0.0f), // front top right - normal: x
        vec3(0.0f, 1.0f, 0.0f), // normal: y
        vec3(0.0f, 0.0f, 1.0f), // normal: z

        vec3(1.0f, 0.0f, 0.0f), // front bottom right - normal: x
        vec3(0.0f, -1.0f, 0.0f), // normal: -y
        vec3(0.0f, 0.0f, 1.0f), // normal: z

        vec3(-1.0f, 0.0f, 0.0f), // back bottom left - normal: -x
        vec3(0.0f, -1.0f, 0.0f), // normal: -y
        vec3(0.0f, 0.0f, -1.0f), // normal: -z

        vec3(-1.0f, 0.0f, 0.0f), // back top left - normal: -x
        vec3(0.0f, 1.0f, 0.0f), // normal: y
        vec3(0.0f, 0.0f, -1.0f), // normal: -z

        vec3(1.0f, 0.0f, 0.0f), // back top right - normal: x
        vec3(0.0f, 1.0f, 0.0f), // normal: y
        vec3(0.0f, 0.0f, -1.0f), // normal: -z

        vec3(1.0f, 0.0f, 0.0f), // back bottom right - normal: x
        vec3(0.0f, -1.0f, 0.0f), // normal: -y
        vec3(0.0f, 0.0f, -1.0f), // normal: -z
    }; 

    std::vector<vec2> cubeUV = {
        // front face
        vec2(0.0f, 0.0f),
        vec2(0.0f, 1.0f),
        vec2(1.0f, 1.0f),

        vec2(1.0f, 1.0f),
        vec2(1.0f, 0.0f),
        vec2(0.0f, 0.0f),

        // back face
        vec2(1.0f, 0.0f),
        vec2(0.0f, 0.0f),
        vec2(0.0f, 1.0f),

        vec2(0.0f, 1.0f),
        vec2(1.0f, 1.0f),
        vec2(1.0f, 0.0f),

        // right side face
        vec2(1.0f, 0.0f),
        vec2(0.0f, 0.0f),
        vec2(0.0f, 1.0f),

        vec2(0.0f, 1.0f),
        vec2(1.0f, 1.0f),
        vec2(1.0f, 0.0f),

        // left side face
        vec2(0.0f, 0.0f),
        vec2(1.0f, 0.0f),
        vec2(1.0f, 1.0f),

        vec2(1.0f, 1.0f),
        vec2(0.0f, 1.0f),
        vec2(0.0f, 0.0f),

        // top face
        vec2(0.0f, 0.0f),
        vec2(0.0f, 1.0f),
        vec2(1.0f, 1.0f),

        vec2(1.0f, 1.0f),
        vec2(1.0f, 0.0f),
        vec2(0.0f, 0.0f),

        // bottom face
        vec2(1.0f, 0.0f),
        vec2(0.0f, 0.0f),
        vec2(0.0f, 1.0f),

        vec2(0.0f, 1.0f),
        vec2(1.0f, 1.0f),
        vec2(1.0f, 0.0f),
    };


    // INDICES OF 3D CUBE USING GL_TRIANGLES 
    std::vector<GLuint> cubeIndices = {
        // front face - CCW - normal: z
        8, 5, 2,
        2, 11, 8,

        // back face - CW - normal: -z
        17, 20, 23,
        23, 14, 17,
        // 5, 6, 7,
        // 7, 4, 5,

        // right side face - CCW - normal: x
        6, 9, 21,
        21, 18, 6,
        // 2, 3, 7,
        // 7, 6, 2,

        //left side face - CW - normal: -x
        3, 15, 12,
        12, 0, 3,
        // 1, 5, 4,
        // 4, 0, 1,

        //top - CCW - normal: y
        16, 4, 7,
        7, 19, 16,
        // 5, 1, 2,
        // 2, 6, 5,

        // bottom - CW - normal: -y
        13, 22, 10,
        10, 1, 13,
        // 4, 7, 3,
        // 3, 0, 4
    };


    // Set up VAO of Cube
    glGenVertexArrays(1, &VAOCubeModel);
    glBindVertexArray(VAOCubeModel);
    
    // Set up VBO of Cube
    glGenBuffers(1, &VBOCubeModel);
    glBindBuffer(GL_ARRAY_BUFFER, VBOCubeModel);
    glBufferData(GL_ARRAY_BUFFER, cubeVertices.size()*sizeof(vec3), &cubeVertices[0][0], GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(vec3), (void*)0);

    // Set up normal vertex attrib pointer using same cube VBO
    glGenBuffers(1, &VBOCubeModel);
    glBindBuffer(GL_ARRAY_BUFFER, VBOCubeModel);
    glBufferData(GL_ARRAY_BUFFER, cubeNormals.size()*sizeof(vec3), &cubeNormals[0][0], GL_STATIC_DRAW);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(vec3), (void*)0);

    // Set up texture vertex attrib pointer using same cube VBO
    glGenBuffers(1, &VBOCubeModel);
    glBindBuffer(GL_ARRAY_BUFFER, VBOCubeModel);
    glBufferData(GL_ARRAY_BUFFER, cubeUV.size()*sizeof(vec2), &cubeUV[0][0], GL_STATIC_DRAW);
    glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, sizeof(vec2), (void*)0);

    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(2);
    glEnableVertexAttribArray(3);
    
    // Set up EBO of 3D Cube Model - Triangles
    glGenBuffers(1, &EBOCubeModel);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBOCubeModel);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, cubeIndices.size()*sizeof(GLuint), &cubeIndices[0], GL_STATIC_DRAW);
    
    EBOCubeModelLength = cubeIndices.size();
}

void drawRacket(mat4 groupRacketMatrix, GLuint colorLocation, GLuint modelMatrixLocation, GLuint EBOCubeModelLength) {


    // RACKET MATRIX TRANSFORMATIONS
    const float racketThickness = 0.2f;
    const float racketNetThickness = 0.05f;
    const float racketLength = 3.0f;
    const float racketCornerLength = 1.5f;
    const float racketNetDeltaX = 0.2f;
    const float racketNetDeltaY = 0.2f;

    // remember: angle is from the vertical
    const float racketCornerUnitX = sin(RACKET_ANGLE) * racketCornerLength; // corner unit x located at top left corner of racketCorner
    const float racketCornerUnitY = cos(RACKET_ANGLE) * racketCornerLength;

    // All racket components
    mat4 racketHandleAndSideDimensions(1.0f);
    mat4 racketCornerMatrix(1.0f);
    mat4 racketBottomLeftCornerMatrix(1.0f);
    mat4 racketBottomRightCornerMatrix(1.0f);
    mat4 racketLeftSideMatrix(1.0f);
    mat4 racketRightSideMatrix(1.0f);
    mat4 racketBottomSideMatrix(1.0f);
    mat4 racketTopSideMatrix(1.0f);
    vec3 translationAboveGrid = vec3(0.0f, 0.5f, 0.0f);

    // Set up matrices transformations
    const float offsetY = racketThickness/2;

    mat4 racketHandleAndSideScale = scale(IDENTITY_MATRIX, vec3(racketThickness, racketLength, racketThickness));
    mat4 racketCornerScale = scale(IDENTITY_MATRIX, vec3(racketThickness, racketCornerLength, racketThickness));
    mat4 racketTranslateAboveGrid = translate(IDENTITY_MATRIX, translationAboveGrid);
    mat4 racketCornerTranslation = translate(IDENTITY_MATRIX, vec3(0.0f, racketLength, 0.0f));
    mat4 racketRotation = rotate(IDENTITY_MATRIX, RACKET_ANGLE, vec3(0.0f, 0.0f, 1.0f));

    mat4 racketLeftSideTranslate = translate(IDENTITY_MATRIX, vec3(-racketCornerUnitX, racketLength + racketCornerUnitY - offsetY, 0.0f));
    mat4 racketRightSideTranslate = translate(IDENTITY_MATRIX, vec3(racketCornerUnitX, racketLength + racketCornerUnitY - offsetY, 0.0f));

    mat4 racketTopAndBottomSideScale = scale(IDENTITY_MATRIX, vec3(racketCornerUnitX * 2, racketThickness, racketThickness));
    mat4 racketBottomSideTranslation = translate(IDENTITY_MATRIX, vec3(0.0f, racketLength + racketCornerUnitY, 0.0f));
    mat4 racketTopSideTranslation = translate(IDENTITY_MATRIX, vec3(0.0f, racketLength + racketCornerUnitY + racketLength - racketThickness, 0.0f ));

    // Calculate matrices transformations for each component of the racket
    racketHandleAndSideDimensions = racketHandleAndSideScale * racketTranslateAboveGrid;
    
    racketCornerMatrix = racketCornerScale * racketTranslateAboveGrid;
    racketBottomLeftCornerMatrix =  racketCornerTranslation * racketRotation * racketCornerMatrix;
    racketBottomRightCornerMatrix = racketCornerTranslation * inverse(racketRotation) * racketCornerMatrix;
    racketLeftSideMatrix = racketLeftSideTranslate * racketHandleAndSideDimensions;
    racketRightSideMatrix = racketRightSideTranslate * racketHandleAndSideDimensions;
    racketBottomSideMatrix = racketBottomSideTranslation * racketTopAndBottomSideScale;
    racketTopSideMatrix = racketTopSideTranslation * racketTopAndBottomSideScale;

    // Every Net Matrix
    
    // RACKET - Render entire model of racket
    // Racket Handle
    glUniform3fv(colorLocation, 1, &colorRed[0]);
    mat4 groupRacketHandleModel = groupRacketMatrix * racketHandleAndSideDimensions;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(groupRacketHandleModel)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    // Racket Bottom Left Corner
    glUniform3fv(colorLocation, 1, &colorWhite[0]);
    mat4 groupRacketBottomLeftCornerMatrix =  groupRacketMatrix * racketBottomLeftCornerMatrix;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(groupRacketBottomLeftCornerMatrix)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    // Racket Bottom Right Corner
    mat4 groupRacketBottomRightCornerMatrix =  groupRacketMatrix * racketBottomRightCornerMatrix;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(groupRacketBottomRightCornerMatrix)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    // Racket Bottom Side
    glUniform3fv(colorLocation, 1, &colorRed[0]);
    mat4 groupRacketBottomSideMatrix =  groupRacketMatrix * racketBottomSideMatrix;
    // mat4 groupRacketBottomSideMatrix = racketBottomSideMatrix;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(groupRacketBottomSideMatrix)[0][0]);
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    // Racket Left Side 
    mat4 groupRacketLeftSideMatrix =  groupRacketMatrix * racketLeftSideMatrix;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(groupRacketLeftSideMatrix)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    // Racket Right Side
    mat4 groupRacketRightSideMatrix =  groupRacketMatrix * racketRightSideMatrix;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(groupRacketRightSideMatrix)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    // Racket Top Side
    mat4 groupRacketTopSideMatrix =  groupRacketMatrix * racketTopSideMatrix;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(groupRacketTopSideMatrix)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    // RACKET NET

    // Racket Net - PLEASE REWRITE CODE USING FOR LOOP
    glUniform3fv(colorLocation, 1, &colorGreen[0]);

    vector<mat4> netMatrices;

    GLfloat netHeight = racketLength;
    GLfloat netWidth = racketCornerUnitX * 2;

    GLfloat netSpacing = 0.15 * netWidth;
    GLfloat netStringThickness = 0.15 * netSpacing;

    vec3 horizontalNetDimensions(netWidth, netStringThickness, netStringThickness);
    vec3 verticalNetDimensions(netStringThickness, netHeight - 0.25f, netStringThickness);
    mat4 netTranslationAboveGrid = translate(IDENTITY_MATRIX, translationAboveGrid);

    // Set up horizontal  nets on y-axis
    vec3 netStringPosition(-netWidth/2, racketThickness/2, 0.0f);
    mat4 netStringMatrix = scale(IDENTITY_MATRIX, verticalNetDimensions) * netTranslationAboveGrid;

    while (netStringPosition.x < netWidth/2) {
        netMatrices.push_back(racketBottomSideTranslation * translate(IDENTITY_MATRIX, netStringPosition) * netStringMatrix);
        netStringPosition.x += netSpacing + verticalNetDimensions.x;
    }

    //Set up Vertical Nets on x-axis
    netStringPosition.y = netSpacing;
    netStringPosition.x = 0.0f;
    netStringMatrix = scale(IDENTITY_MATRIX, horizontalNetDimensions) * netTranslationAboveGrid;

    while (netStringPosition.y < netHeight - 0.25f) {
        netMatrices.push_back(racketBottomSideTranslation * translate(IDENTITY_MATRIX, netStringPosition) * netStringMatrix);
        netStringPosition.y += netSpacing + horizontalNetDimensions.y;
    }

    // Loop through all of net matrices and draw
    for (int i = 0; i < netMatrices.size(); i++) {
        mat4 groupNetMatrix = groupRacketMatrix * netMatrices[i];
        glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &groupNetMatrix[0][0]);
        glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);
    }
}

void drawTennisNet(GLuint colorLocation, GLuint modelMatrixLocation, GLuint EBOCubeModelLength, GLuint brickTextureId, GLuint glossyTextureId) {
    vector<mat4> netMatrices;
    const float netThickness = 0.2f;
    const float spacing = 0.5f;
    float positionZ = 0.0f;
    float positionY = 0.0f;

    mat4 translationAboveGrid = translate(IDENTITY_MATRIX, vec3(0.0f, 0.5f, 0.0f));

    vec3 verticalNet(netThickness, 5, netThickness);
    vec3 horizontalNet(netThickness, netThickness, GRID_SLICES_Z);

    mat4 verticalNetMatrix = scale(IDENTITY_MATRIX, verticalNet) * translationAboveGrid;
    mat4 horizontalNetMatrix = scale(IDENTITY_MATRIX, horizontalNet) * translationAboveGrid;

    // Add all matrix transformations for horizontal nets located on Z axis
    while (positionZ <= GRID_SLICES_Z/2.0f) {
        netMatrices.push_back(translate(IDENTITY_MATRIX, vec3(0.0f, 0.0f, positionZ)) * verticalNetMatrix);
        netMatrices.push_back(translate(IDENTITY_MATRIX, vec3(0.0f, 0.0f, -positionZ)) * verticalNetMatrix);
        positionZ += netThickness + spacing;
    }

    // Add all matrix transformations for vertical nets located on Z axis
    while (positionY <= verticalNet.y) {
        netMatrices.push_back(translate(IDENTITY_MATRIX, vec3(0.0f, positionY, 0.0f)) * horizontalNetMatrix);
        positionY += netThickness + spacing;

    }

    glBindTexture(GL_TEXTURE_2D, glossyTextureId);
    // Loop through every matrix and draw corresponding net
    for (int i = 0; i < netMatrices.size(); i++) {
        glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(netMatrices[i])[0][0]);
        glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);
    }

    // Render Net Pillars
    vec3 netPillarDimensions(0.5f, verticalNet.y, 0.5f);
    mat4 netPillarMatrix = scale(IDENTITY_MATRIX, netPillarDimensions) * translationAboveGrid;

    vec3 topRowNetDimensions(0.5f, 1.0f, GRID_SLICES_Z + 1);
    mat4 topRowNetMatrix = scale(IDENTITY_MATRIX, topRowNetDimensions) * translationAboveGrid;

    mat4 whiteTopRowNetMatrix = translate(IDENTITY_MATRIX, vec3(0.0f, verticalNet.y, 0.0f)) * topRowNetMatrix;
    mat4 redPillarMatrix = translate(IDENTITY_MATRIX, vec3(0.0f, 0.0f, positionZ)) * netPillarMatrix;
    mat4 bluePillarMatrix = translate(IDENTITY_MATRIX, vec3(0.0f, 0.0f, -positionZ)) * netPillarMatrix;
    mat4 yellowPillarMatrix = translate(IDENTITY_MATRIX, vec3(0.0f, 0.0f, 0.0f)) * netPillarMatrix;

    // Change texture to brick first for pillars
    glBindTexture(GL_TEXTURE_2D, brickTextureId);

    glUniform3fv(colorLocation, 1, &colorRed[0]);
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(redPillarMatrix)[0][0]);
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    glUniform3fv(colorLocation, 1, &colorBlue[0]);
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(bluePillarMatrix)[0][0]);
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    glUniform3fv(colorLocation, 1, &colorYellow[0]);
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(yellowPillarMatrix)[0][0]);
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    // Change texture of top row to glossy
    glBindTexture(GL_TEXTURE_2D, glossyTextureId);
    glUniform3fv(colorLocation, 1, &colorWhite[0]);
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(whiteTopRowNetMatrix)[0][0]);
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);
}

void drawDModel(mat4 groupRacketMatrix, GLuint colorLocation, GLuint modelMatrixLocation, GLuint EBOCubeModelLength) {
    const float dWidth = 2.0f;
    const float dHeight = 0.3f;
    const float dThickness = 0.3f;


    mat4 dBottomSideScale = scale(IDENTITY_MATRIX, vec3(dWidth, dHeight, dThickness));
    mat4 dLeftSideScale = scale(IDENTITY_MATRIX, vec3(dHeight, dWidth, dThickness));
    mat4 dLeftSideTranslate = translate(IDENTITY_MATRIX, vec3(-dWidth/2, 2.0f/2, 0.0f));
    mat4 dTopSideTranslate = translate(IDENTITY_MATRIX, vec3(0.0f, 2.0f, 0.0f));
    mat4 dRightSideScale = scale(IDENTITY_MATRIX, vec3(dHeight, dWidth * 2, dThickness));
    mat4 dRightSideTranslate = translate(IDENTITY_MATRIX, vec3(dWidth/2, dWidth, 0.0f));

    mat4 dBottomSide = (groupRacketMatrix * TRANSLATE_ABOVE_RACKET ) * dBottomSideScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(dBottomSide)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    mat4 dTopSide = (groupRacketMatrix * TRANSLATE_ABOVE_RACKET * dTopSideTranslate) * dBottomSideScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(dTopSide)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    mat4 dLeftSide = (groupRacketMatrix * TRANSLATE_ABOVE_RACKET * dLeftSideTranslate) * dLeftSideScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(dLeftSide)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    mat4 dRightSide = (groupRacketMatrix * TRANSLATE_ABOVE_RACKET * dRightSideTranslate) * dRightSideScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(dRightSide)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

}

void drawAModel(mat4 groupRacketMatrix, GLuint colorLocation, GLuint modelMatrixLocation, GLuint EBOCubeModelLength) {
    const float aWidth = 2.0f;
    const float aHeight = 0.3f;
    const float aThickness = 0.3f;


    mat4 aBottomSideScale = scale(IDENTITY_MATRIX, vec3(aWidth, aHeight, aThickness));
    mat4 aLeftSideScale = scale(IDENTITY_MATRIX, vec3(aHeight, aWidth, aThickness));
    mat4 aLeftSideTranslate = translate(IDENTITY_MATRIX, vec3(-aWidth/2, 2.0f/2, 0.0f));
    mat4 aMiddleSideTranslate = translate(IDENTITY_MATRIX, vec3(0.0f, 2.0f, 0.0f));
    mat4 aRightSideScale = scale(IDENTITY_MATRIX, vec3(aHeight, aWidth * 1.5, aThickness));
    mat4 aRightSideTranslate = translate(IDENTITY_MATRIX, vec3(aWidth/2, aWidth*0.67, 0.0f));
    mat4 aTopSideTranslate = translate(IDENTITY_MATRIX, vec3(0.0f, aWidth * 1.5, 0.0f));

    mat4 aBottomSide = ( groupRacketMatrix * TRANSLATE_ABOVE_RACKET ) * aBottomSideScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(aBottomSide)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    mat4 aMiddleSide = (groupRacketMatrix * TRANSLATE_ABOVE_RACKET * aMiddleSideTranslate) * aBottomSideScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(aMiddleSide)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    mat4 aLeftSide = (groupRacketMatrix * TRANSLATE_ABOVE_RACKET * aLeftSideTranslate) * aLeftSideScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(aLeftSide)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    mat4 aRightSide = (groupRacketMatrix * TRANSLATE_ABOVE_RACKET * aRightSideTranslate) * aRightSideScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(aRightSide)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    mat4 aTopSide = (groupRacketMatrix * TRANSLATE_ABOVE_RACKET * aTopSideTranslate) * aBottomSideScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(aTopSide)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

}

void drawNModel(mat4 groupRacketMatrix, GLuint colorLocation, GLuint modelMatrixLocation, GLuint EBOCubeModelLength) {
    const float aWidth = 2.0f;
    const float aHeight = 0.3f;
    const float aThickness = 0.3f;

    mat4 NLeftSideScale = scale(IDENTITY_MATRIX, vec3(aHeight, aWidth, aThickness));
    mat4 NLeftSideTranslate = translate(IDENTITY_MATRIX, vec3(-aWidth/2, 0.0f, 0.0f));
    mat4 NTopSideScale = scale(IDENTITY_MATRIX, vec3(aWidth, aHeight, aThickness));
    mat4 NTopSideTranslate = translate(IDENTITY_MATRIX, vec3(0.0f, aWidth/2, 0.0f));
    mat4 NRightSideTranslate = translate(IDENTITY_MATRIX, vec3(aWidth/2, 0.0f, 0.0f));

    mat4 nLeftSide = (groupRacketMatrix * TRANSLATE_ABOVE_RACKET * NLeftSideTranslate) * NLeftSideScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(nLeftSide)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    mat4 nTopSide = (groupRacketMatrix * TRANSLATE_ABOVE_RACKET  * NTopSideTranslate) * NTopSideScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(nTopSide)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    mat4 nRightSide = (groupRacketMatrix * TRANSLATE_ABOVE_RACKET  * NRightSideTranslate) * NLeftSideScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(nRightSide)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);


}

void drawIModel(mat4 groupRacketMatrix, GLuint colorLocation, GLuint modelMatrixLocation, GLuint EBOCubeModelLength) {
    const float iWidth = 2.0f;
    const float iHeight = 0.3f;
    const float iThickness = 0.3f;

    mat4 iBottomSideScale = scale(IDENTITY_MATRIX, vec3(iHeight, iWidth, iThickness));
    mat4 iDotScale = scale(IDENTITY_MATRIX, vec3(iHeight, iHeight, iHeight));
    mat4 iDotTranslate = translate(IDENTITY_MATRIX, vec3(0.0f, iWidth + 1.0f, 0.0f));

    mat4 iBottomSide =  (groupRacketMatrix * TRANSLATE_ABOVE_RACKET) * iBottomSideScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(iBottomSide)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

    mat4 iDot =  (groupRacketMatrix * TRANSLATE_ABOVE_RACKET * iDotTranslate) * iDotScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(iDot)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

}

void drawSkybox(GLuint colorLocation, GLuint modelMatrixLocation, GLuint EBOCubeModelLength) {
    const float modifier = 100.0f;

    mat4 skyboxScale = scale(IDENTITY_MATRIX, vec3(-GRID_SLICES_X, -modifier, -GRID_SLICES_Z));

    mat4 skybox = skyboxScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(skybox)[0][0]); 
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

}

// drawFloor() sets up scale and translation for the floor cube
void drawFloor(GLuint colorLocation, GLuint modelMatrixLocation, GLuint EBOCubeModelLength) {
    mat4 floorScale = scale(IDENTITY_MATRIX, vec3(GRID_SLICES_X, 0.5f, GRID_SLICES_Z));
    mat4 floorTranslation = translate(IDENTITY_MATRIX, vec3(0.0f, -0.55f, 0.0f));

    mat4 floorMatrix = floorTranslation * floorScale;
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &floorMatrix[0][0]);
    glDrawElements(GL_TRIANGLES, EBOCubeModelLength, GL_UNSIGNED_INT, 0);

}

// loadTexture() takes a filename and renders a certain texture for use
GLuint loadTexture(const char *filename)
{
  // Step1 Create and bind textures
  GLuint textureId = 0;
  glGenTextures(1, &textureId);
  assert(textureId != 0);


  glBindTexture(GL_TEXTURE_2D, textureId);

  // Step2 Set filter parameters
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

  // Step3 Load Textures with dimension data
  int width, height, nrChannels;
  unsigned char *data = stbi_load(filename, &width, &height, &nrChannels, 0);

  if(stbi_failure_reason())
    std::cout << stbi_failure_reason();

  if (!data)
  {
    std::cerr << "\nError::Texture could not load texture file:" << filename << std::endl;
    return 0;
  }

  // Step4 Upload the texture to the PU
  GLenum format = 0;
  if (nrChannels == 1)
      format = GL_RED;
  else if (nrChannels == 3)
      format = GL_RGB;
  else if (nrChannels == 4)
      format = GL_RGBA;
  glTexImage2D(GL_TEXTURE_2D, 0, format, width, height,
               0, format, GL_UNSIGNED_BYTE, data);

  // Step5 Free resources
  stbi_image_free(data);
  glBindTexture(GL_TEXTURE_2D, 0);
  return textureId;
}


int main(int argc, char * argv[]) {

    // -------------- 1. INITIALIZE GLFW AND SHADERS ---------------

    // Init the glfw library and set various configurations.
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);

    // Create a glfw window with specified size
    // glfwCreateWindow(width, size, title, monitor, share)
    GLFWwindow * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, "COMP 371 - Quiz 2", NULL, NULL);
    // If cannot create window we abort the program.
    if (!window) {
        std::cerr << "Failed to open GLFW Window." << std::endl;
        exit(EXIT_FAILURE);
    }
    // Set context current context to this window.
    glfwMakeContextCurrent(window);

    // Initialize GLEW
    // Set experimental features needed for core profile
    glewExperimental = true;
    // init glew and check if it was properly init.
    if (glewInit() != GLEW_OK) {
        std::cerr << "Failed to init GLEW" << std::endl;
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

     // -------------------- TEXTURE SHADER - CHANGE SO THAT IT ONLY USES THIS ---------------
    // create texture shader program
    GLuint textureVertexShaderId = loadAndCompileShader(textureVertexShaderSource, GL_VERTEX_SHADER);
    GLuint textureFragmentShaderId = loadAndCompileShader(textureFragmentShaderSource, GL_FRAGMENT_SHADER);

    GLuint textureShaderProgram = glCreateProgram();
    glAttachShader(textureShaderProgram, textureVertexShaderId);
    glAttachShader(textureShaderProgram, textureFragmentShaderId);
    glLinkProgram(textureShaderProgram);
    
    // check if link was properly done
    int success;
    char infoLog[INFO_LOG_SIZE];
    glGetProgramiv(textureShaderProgram, GL_LINK_STATUS, &success);
    if (!success) {
        glGetProgramInfoLog(textureShaderProgram, INFO_LOG_SIZE, NULL, infoLog);
        std::cerr << "ERROR::TEXTURE SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
    }

    // ---------------------- END --------------------------

    // Assign OpenGL to use shaderProgram that we've set
    glUseProgram(textureShaderProgram);

    // Initialize uniform for color
    GLuint colorLocation = glGetUniformLocation(textureShaderProgram, "color");

    // General Clean Up
    glDeleteShader(textureVertexShaderId);
    glDeleteShader(textureFragmentShaderId);
    

    // Enables the Depth Buffer
	glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);

    // Background color
    glClearColor(57/255.0f, 62/255.0f, 67/255.0f, 1.0f);

    // Set the viewport to avoid the jittering in the beginning.
    GLint frameBufferWidth, frameBufferHeight;
    glfwGetFramebufferSize(window, &frameBufferWidth, &frameBufferHeight);
    glViewport(0, 0, frameBufferWidth, frameBufferHeight);

    // -------------- 2. INITIALIZE VAOs ---------------

    // VAOGrid for grid
    GLuint VAOGrid, VBOGrid, EBOGrid, EBOGridLength;
    computeGrid(VAOGrid, VBOGrid, EBOGrid, EBOGridLength);

    // VAO for cube
    GLuint VAOCubeModel, VBOCubeModel, EBOCubeModel, EBOCubeModelLength;
    drawCubeModel(VAOCubeModel, VBOCubeModel, EBOCubeModel, EBOCubeModelLength);

    // VAO for net
    GLuint VAONetModel, VBONetModel, EBONetModel, EBONetModelLength;
    drawCubeModel(VAONetModel, VBONetModel, EBONetModel, EBONetModelLength);

    // VAO for d
    GLuint VAODModel, VBODModel, EBODModel, EBODModelLength;
    drawCubeModel(VAODModel, VBODModel, EBODModel, EBODModelLength);

    // VAO for a
    GLuint VAOAModel, VBOAModel, EBOAModel, EBOAModelLength;
    drawCubeModel(VAOAModel, VBOAModel, EBOAModel, EBOAModelLength);

    // VAO for n
    GLuint VAONModel, VBONModel, EBONModel, EBONModelLength;
    drawCubeModel(VAONModel, VBONModel, EBONModel, EBONModelLength);

    // VAO for I
    GLuint VAOIModel, VBOIModel, EBOIModel, EBOIModelLength;
    drawCubeModel(VAOIModel, VBOIModel, EBOIModel, EBOIModelLength);

    GLuint VAOSkybox, VBOSkybox, EBOSkybox, EBOSkyboxLength;
    drawCubeModel(VAOSkybox, VBOSkybox, EBOSkybox, EBOSkyboxLength);

    // unbind VAOGrid, VBOGrid and EBOGrid for clean up
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    // ------------------------- 2.5 TEXTURES -----------------------

    GLuint metallicTextureId = loadTexture("/COMP371/src/textures/metal.jpg");
    GLuint clayTextureId = loadTexture("/COMP371/src/textures/clay.jpg");
    GLuint glossyTextureId = loadTexture("/COMP371/src/textures/glossy.jpg");
    GLuint brickTextureId = loadTexture("/COMP371/src/textures/brick.jpg");
    GLuint woodTextureId = loadTexture("/COMP371/src/textures/wood.jpg");
    GLuint skyTextureId = loadTexture("/COMP371/src/textures/sky.jpg");
    GLuint stoneTextureId = loadTexture("/COMP371/src/textures/stone.jpg");
    GLuint sesameTextureId = loadTexture("/COMP371/src/textures/sesame.jpg");
    GLuint paperTextureId = loadTexture("/COMP371/src/textures/paper.jpg");
    GLuint tennisTextureId = loadTexture("/COMP371/src/textures/tennis.jpg");
    GLuint floorTextureId = loadTexture("/COMP371/src/textures/floor.jpg");

    // --------------- 3. INITIALIZE MATRICES AND RENDER -----------

    // Initialize MVP matrices of the entire world to identity matrices
    mat4 modelMatrix(1.0f);
    mat4 viewMatrix(1.0f);
    mat4 projectionMatrix(1.0f);

    // --> RACKET MATRIX TRANSFORMATIONS
    GLfloat movementSpeed = 1.0f;
    mat4 movementTranslationMatrix(1.0f);
    mat4 movementScaleMatrix(1.0f);

    // Set up group rackets
    mat4 groupFirstRacketDATranslate = translate(IDENTITY_MATRIX, vec3(-GRID_SLICES_X/4.0f, 0.0f, 0.0f)); // located upper left of grid
    mat4 groupSecondRacketNITranslate = translate(IDENTITY_MATRIX, vec3(GRID_SLICES_X/4.0f, 0.0f, 0.0f)); // located bottom left of grid
    
    // Initial Translation
    groupFirstRacketDA.racketTranslation = groupFirstRacketDATranslate;
    groupSecondRacketNI.racketTranslation = groupSecondRacketNITranslate;
    

    groupFirstRacketDA.updateGroupMatrix();
    groupSecondRacketNI.updateGroupMatrix();

    // MATRIX TRANSLATIONS FOR ALPHABET
    mat4 leftLetterTranslate = translate(IDENTITY_MATRIX, vec3(-1.3f, 0.0f, 0.0f));
    mat4 rightLetterTranslate = translate(IDENTITY_MATRIX, vec3(1.3f, 0.0f, 0.0f));

    // Initial lookAt camera angle
    viewMatrix = lookAt(vec3(7.0f, 10.0f, 10.0f), vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f));

    // ----------------- 5. SPOTLIGHT -------------------
    vec3 lightPos(0.0f, 0.0f, 30.0f);
    GLuint lightLocation = glGetUniformLocation(textureShaderProgram, "lightPos");
    glUniform3fv(lightLocation, 1, &lightPos[0]);
    

    // Inputs
    GLfloat lastFrameTime = glfwGetTime();
    GLuint spacebarLastState = glfwGetKey(window, GLFW_KEY_SPACE);

    while(!glfwWindowShouldClose(window)) {

        // TIMER CODE
        // dt = delta time
        GLfloat dt = glfwGetTime() - lastFrameTime;
        lastFrameTime += dt;

        // clear current buffer
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        GLuint modelMatrixLocation = glGetUniformLocation(textureShaderProgram, "model");
        glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &modelMatrix[0][0]);

        // Set LookAt at ViewMatrix to see corner of cube (default camera position)
        GLuint viewMatrixLocation = glGetUniformLocation(textureShaderProgram, "view");
        glUniformMatrix4fv(viewMatrixLocation, 1 , GL_FALSE, &viewMatrix[0][0]);

        // Set Projection Matrix to perspective view as default
        projectionMatrix = perspective(radians(100.0f), ASPECT_RATIO, 0.01f, 1000.0f);
        GLuint projectionMatrixLocation = glGetUniformLocation(textureShaderProgram, "proj");
        glUniformMatrix4fv(projectionMatrixLocation, 1, GL_FALSE, &projectionMatrix[0][0]);
        
        // ACTIVATE TEXTURES
        glActiveTexture(GL_TEXTURE0);
        GLuint textureLocation = glGetUniformLocation(textureShaderProgram, "textureSampler");
        glUniform1i(textureLocation, 0);

        // draw Skybox
        glBindTexture(GL_TEXTURE_2D, skyTextureId);
        glUniform3fv(colorLocation, 1, &colorSkybox[0]);
        glBindVertexArray(VAOSkybox);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBOSkybox);
        drawSkybox( colorLocation,  modelMatrixLocation,  EBOCubeModelLength);

        // CUBE - Render the base 3D Cube
        glBindVertexArray(VAOCubeModel);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBOCubeModel);

        // FLOOR - Render floor below grid
        glBindTexture(GL_TEXTURE_2D, floorTextureId);
        glUniform3fv(colorLocation, 1, &colorGreen[0]);
        drawFloor(colorLocation, modelMatrixLocation, EBOCubeModelLength); // draw floor as tennis

        
        // RACKETS - Render the 4 rackets
        // Change texture to metal for rackets
        glBindTexture(GL_TEXTURE_2D, metallicTextureId);

        glUniform3fv(colorLocation, 1, &colorRed[0]);
        drawRacket(groupFirstRacketDA.groupMatrix, colorLocation, modelMatrixLocation, EBOCubeModelLength); // racket DA
        drawRacket(groupSecondRacketNI.groupMatrix, colorLocation, modelMatrixLocation, EBOCubeModelLength); // racket NI 

        // ALPHABET - render d a n i
        // Letter D 
        glUniform3fv(colorLocation, 1, &colorBlue[0]);
        glBindVertexArray(VAODModel);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBODModel);
        glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(groupFirstRacketDA.groupMatrix)[0][0]);
        
        glBindTexture(GL_TEXTURE_2D, brickTextureId);
        drawDModel((groupFirstRacketDA.groupMatrix * leftLetterTranslate), colorLocation, modelMatrixLocation, EBOCubeModelLength);

        
        // Letter A
        glUniform3fv(colorLocation, 1, &colorRed[0]);
        glBindVertexArray(VAOAModel);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBOAModel);
        glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(groupFirstRacketDA.groupMatrix)[0][0]);
        
        glBindTexture(GL_TEXTURE_2D, woodTextureId);
        drawAModel((groupFirstRacketDA.groupMatrix * rightLetterTranslate), colorLocation, modelMatrixLocation, EBOCubeModelLength);

        
        // Letter N
        glUniform3fv(colorLocation, 1, &colorGreen[0]);
        glBindVertexArray(VAONModel);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBOAModel);
        glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(groupSecondRacketNI.groupMatrix)[0][0]);
        
        glBindTexture(GL_TEXTURE_2D, sesameTextureId);
        drawNModel((groupSecondRacketNI.groupMatrix * leftLetterTranslate), colorLocation, modelMatrixLocation, EBOCubeModelLength);

        
        // Letter I
        glUniform3fv(colorLocation, 1, &colorYellow[0]);
        glBindVertexArray(VAOIModel);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBOIModel);
        glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &(groupSecondRacketNI.groupMatrix)[0][0]);

        glBindTexture(GL_TEXTURE_2D, paperTextureId);
        drawIModel((groupSecondRacketNI.groupMatrix * rightLetterTranslate), colorLocation, modelMatrixLocation, EBOCubeModelLength);

        
        // GRID - Render the X,Z plane grid
        glUniform3fv(colorLocation, 1, &colorYellow[0]);
        glBindVertexArray(VAOGrid);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBOGrid);
        glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &modelMatrix[0][0]);
        glDrawElements(GL_LINES, EBOGridLength, GL_UNSIGNED_INT, 0);

        // NET - Render the Tennis Net
        glUniform3fv(colorLocation, 1, &colorGray[0]);
        glBindVertexArray(VAONetModel);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBONetModel);
        glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &modelMatrix[0][0]);
        drawTennisNet(colorLocation, modelMatrixLocation, EBOCubeModelLength, brickTextureId, glossyTextureId);


        // swap the buffer to the one already written, and place the current one as a canvas
        glfwSwapBuffers(window);
        glfwPollEvents();

        bool isShiftKeyPressed = (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_RIGHT_SHIFT) == GLFW_PRESS);

         // ------- INPUT EVENTS ----------
        if (glfwGetKey(window, GLFW_KEY_Z) == GLFW_PRESS) {
            // viewMatrix = mat4(1.0f);
            viewMatrix = lookAt(vec3(0.0f, 10.0f, 10.0f), vec3(0.0f, 5.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f));
        }

        if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS) {
            viewMatrix = lookAt(vec3(1.5f, 10.0f, 10.0f), vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f));
        }

        if (glfwGetKey(window, GLFW_KEY_C) == GLFW_PRESS) {
            viewMatrix = lookAt(vec3(0.0f, 10.0f, 0.0f), vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 0.0f, -1.0f));
        }

        if (glfwGetKey(window, GLFW_KEY_V) == GLFW_PRESS) {
            viewMatrix = lookAt(vec3(0.0f, 4.0f, 7.0f), vec3(0.0f, 3.0f, -4.0f), vec3(0.0f, 0.0f, -1.0f));
        }

        if (glfwGetKey(window, GLFW_KEY_B) == GLFW_PRESS) {
            viewMatrix = lookAt(vec3(0.0f, 10.0f, 25.0f), vec3(0.0f, 9.0f, -4.0f), vec3(0.0f, 0.0f, -1.0f));
        }

        if (glfwGetKey(window, GLFW_KEY_N) == GLFW_PRESS) {
            viewMatrix = lookAt(vec3(0.0f, 2.0f, 4.0f), vec3(0.0f, 2.0f, -4.0f), vec3(0.0f, 1.0f, 0.0f));
        }

        if (glfwGetKey(window, GLFW_KEY_M) == GLFW_PRESS) {
            viewMatrix = lookAt(vec3(25.0f, 15.0f, 50.0f), vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f));
        }
        if (glfwGetKey(window, GLFW_KEY_COMMA) == GLFW_PRESS) {
            viewMatrix = lookAt(vec3(0.0f, 50.0f, 0.0f), vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 0.0f, -1.0f));
        }
        if (glfwGetKey(window, GLFW_KEY_PERIOD) == GLFW_PRESS) {
            viewMatrix = lookAt(vec3(15.0f, 0.5f, 0.0f), vec3(0.0f, 0.5f, 0.0f), vec3(0.0f,  1.0f, 0.0f));
        }
        if (glfwGetKey(window, GLFW_KEY_SLASH) == GLFW_PRESS) {
            viewMatrix = lookAt(vec3(110.0f, 110.0f, 110.0f), vec3(0.0f, 0.0f, 0.0f), vec3(0.0f,  1.0f, 0.0f));
            
        }

        // Setting Camera to selected racket
        if (currentlySelectedGroupRacket != NULL) {
            viewMatrix = lookAt(currentlySelectedGroupRacket->returnRacketCenter() + vec3(0.0f, 0.0f, GRID_SLICES_Z/4), currentlySelectedGroupRacket->returnRacketCenter(), vec3(0.0f,  1.0f, 0.0f));
        }

        // SELECT RACKET
        if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS) {
            currentlySelectedGroupRacket = &groupFirstRacketDA;
            // viewMatrix = lookAt(currentlySelectedGroupRacket->racketTranslation * vec4(0.0f, 7.0f, 0.0f, 1.0f), vec3(-GRID_SLICES_X/4.0f, 7.0f, -50.0f), vec3(0.0f,  1.0f, 0.0f));

        }
        if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS) {
            currentlySelectedGroupRacket = &groupSecondRacketNI;
            // viewMatrix = lookAt(vec3(-GRID_SLICES_X/4.0f, 7.0f, GRID_SLICES_Z/2), vec3(-GRID_SLICES_X/4.0f, 7.0f, -50.0f), vec3(0.0f,  1.0f, 0.0f));
            
        }

        // CONTROL MODEL POSITION AND ORIENTATION - WASD keys
        if (currentlySelectedGroupRacket != NULL && glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS && isShiftKeyPressed) {
            float travelDistance = movementSpeed * dt;
            mat4 distanceTranslate = translate(IDENTITY_MATRIX, vec3(0.0f, travelDistance, 0.0f) );
            currentlySelectedGroupRacket->racketTranslation = distanceTranslate * currentlySelectedGroupRacket->racketTranslation;
            currentlySelectedGroupRacket->updateGroupMatrix();
        }
        
        if (currentlySelectedGroupRacket != NULL && glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS && isShiftKeyPressed) {

            float travelDistance = movementSpeed * dt;
            mat4 distanceTranslate = translate(IDENTITY_MATRIX, vec3(-travelDistance, 0.0f, 0.0f) );
            currentlySelectedGroupRacket->racketTranslation = distanceTranslate * currentlySelectedGroupRacket->racketTranslation;
            currentlySelectedGroupRacket->updateGroupMatrix();
            

        } else if (currentlySelectedGroupRacket != NULL && glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
            mat4 rotationTransformation = rotate(mat4(1.0f), 5.f/360.f*pi<float>(), vec3(0.f, 1.f, 0.f));
            currentlySelectedGroupRacket->racketRotation = rotationTransformation * currentlySelectedGroupRacket->racketRotation;
            currentlySelectedGroupRacket->updateGroupMatrix();
        }

        if (currentlySelectedGroupRacket != NULL && glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS && isShiftKeyPressed) {
            float travelDistance = movementSpeed * dt;
            mat4 distanceTranslate = translate(IDENTITY_MATRIX, vec3(0.0f, -travelDistance, 0.0f) );
            currentlySelectedGroupRacket->racketTranslation = distanceTranslate * currentlySelectedGroupRacket->racketTranslation;
            currentlySelectedGroupRacket->updateGroupMatrix();

        }

        if (currentlySelectedGroupRacket != NULL && glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS && isShiftKeyPressed) {
            float travelDistance = movementSpeed * dt;
            mat4 distanceTranslate = translate(IDENTITY_MATRIX, vec3(travelDistance, 0.0f, 0.0f) );
            currentlySelectedGroupRacket->racketTranslation = distanceTranslate * currentlySelectedGroupRacket->racketTranslation;
            currentlySelectedGroupRacket->updateGroupMatrix();
            
        } else if (currentlySelectedGroupRacket != NULL && glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
            mat4 rotationTransformation = rotate(IDENTITY_MATRIX, -5.0f/360.f*pi<float>(), vec3(0.0f, 1.0f, 0.0f));
            currentlySelectedGroupRacket->racketRotation = rotationTransformation * currentlySelectedGroupRacket->racketRotation;
            currentlySelectedGroupRacket->updateGroupMatrix();
        }


        // Upon pressing escape, stop window, and terminate program later.
        if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
            glfwSetWindowShouldClose(window, true);

    }

    // Terminate the program.
    glDeleteProgram(textureShaderProgram);
    glfwTerminate();
}